# V2 ecosystem templates

Source logos and the sourced Vitruveo website headline. White/empty areas are for owner-supplied imagery. These are templates, not finished campaigns.
