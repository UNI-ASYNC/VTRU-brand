# verticalfoundation — V2 general templates

Supplied logos and existing website copy only. Open areas are reserved for the team’s existing imagery. This package contains the platform templates and supplemental/document templates for this brand.

Browse the complete V2 gallery at https://github.com/UNI-ASYNC/VTRU-brand/blob/main/v2/GALLERY.md . V1 evidence remains separate.
