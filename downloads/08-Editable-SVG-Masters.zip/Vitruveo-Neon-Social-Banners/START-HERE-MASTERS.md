# Editable SVG masters — all 79 social banner layouts

Extract this entire ZIP and preserve its folder structure. Each SVG refers to the two shared background PNGs in `00-Guide-and-Audit/Backgrounds/`. The brand logos are embedded directly in each SVG. Fonts and their license are included.

This part contains editable masters and supporting files. Finished upload PNGs are supplied in the seven separate `*-PNGs.zip` downloads. Extracting all parts into one location merges the common `Vitruveo-Neon-Social-Banners` folder.

The original audit and asset manifests describe the complete production set, including the separately delivered upload PNGs. `CHECKSUMS-08-Editable-SVG-Masters.txt` covers only the files physically included in this archive.

Collections 01 and 02 contain the four-brand and five-brand ecosystem layouts. Collections 03–07 contain individual brand layouts. Platform subfolders identify the intended upload surface. Keep all source logo colors, geometry and proportions unchanged when editing.
